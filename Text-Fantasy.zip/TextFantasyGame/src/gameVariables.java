
public class gameVariables {
	final static double maxHealth = 2000;
	final static double maxMana = 2000;
	final static double maxDamage = 1500;
	final static double maxDefence = 1500;
	final static double maxStealth = 100;
	
	public static double getMaxHealth(){
		return maxHealth;
	}
	
	public static double getMaxMana(){
		return maxMana;
	}
	
	public static double getMaxDamage(){
		return maxDamage;
	}
	
	public static double getMaxDefence(){
		return maxDefence;
	}
	
	public static double getMaxStealth(){
		return maxStealth;
	}
}

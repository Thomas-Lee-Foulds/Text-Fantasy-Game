
public class Player {
	String role;
	double health;
	double mana;
	double physicalDamage;
	double magicDamage;
	double defence;
	double stealth;
	boolean dead;
	public Player(String role, double health, double mana, double physicalDamage, double magicDamage, 
			double defence, double stealth, boolean dead){
		this.role = role;
		this.health = health;
		this.mana = mana;
		this.physicalDamage = physicalDamage;
		this.magicDamage = magicDamage;
		this.defence = defence;
		this.stealth = stealth;
		this.dead = dead;
	}
	
	public static Player initialisePlayer(){
		Player player = new Player("n/a",0,0,0,0,0,0,false);
		return player;
	}
	
	public static Player createWarrior(Player player){
		player.role = "Warrior";
		player.health = 50;
		player.mana = 0;
		player.physicalDamage = 20;
		player.magicDamage = 0;
		player.defence = 30;
		player.stealth = 15;
		player.dead = false;
		return player;
	}
	
	public static Player createMage(Player player){
		player.role = "Mage";
		player.health = 30;
		player.mana = 30;
		player.physicalDamage = 2;
		player.magicDamage = 20;
		player.defence = 20;
		player.stealth = 25;
		player.dead = false;
		return player;
	}
	
	public static Player createAssasin(Player player){
		player.role = "Assasin";
		player.health = 20;
		player.mana = 20;
		player.physicalDamage = 50;
		player.magicDamage = 0;
		player.defence = 0;
		player.stealth = 50;
		player.dead = false;
		return player;
	}
	
	public static void addHealth(Player player){
		double healthBoost = (Math.random()*0.5) + 1;
		double origHealth = player.health;
		player.health *= healthBoost;
		if(player.health > gameVariables.getMaxHealth()){
			System.out.println("Health cannot be increased over " + gameVariables.getMaxHealth());
			player.health /= healthBoost;
			return;
		}
		System.out.printf("Health increased by %.2f\n" ,(player.health-origHealth));
	}
	
	public static void addMana(Player player){
		double manaBoost = (Math.random()*0.5) + 1;
		double origMana = player.mana; 
		player.mana *= manaBoost;
		if(player.mana > gameVariables.getMaxMana()){
			System.out.println("Mana cannot be increased over " + gameVariables.getMaxMana());
			player.mana /= manaBoost;
			return;
		}
		System.out.printf("Mana increased by %.2f\n" ,(player.mana-origMana));
	}
	
	public static void addPhysicalDamage(Player player){
		double damageBoost = (Math.random()*0.5) + 1;
		double originalPhys = player.physicalDamage;
		player.physicalDamage *= damageBoost;
		if(player.physicalDamage > gameVariables.getMaxDamage()){
			System.out.println("Physical damage cannot be increased over " + gameVariables.getMaxDamage());
			player.physicalDamage /= damageBoost;
			return;
		}
		System.out.printf("physical Damage increased by %.2f\n" , (player.physicalDamage-originalPhys));
	}
	
	public static void addMagicDamage(Player player){
		double damageBoost = (Math.random()*0.5) + 1;
		double originalMagic = player.magicDamage;
		player.magicDamage *= damageBoost;
		if(player.magicDamage > gameVariables.getMaxDamage()){
			System.out.println("Magic damage cannot be increased over " + gameVariables.getMaxDamage());
			player.magicDamage /= damageBoost;
			return;
		}
		System.out.printf("Magic Damage increased by %.2f\n",(player.magicDamage - originalMagic));
	}
	
	public static void addDefence(Player player){
		double defenceBoost = (Math.random()*0.5) + 1;
		double originalDef = player.defence;
		player.defence *= defenceBoost;
		if(player.defence > gameVariables.getMaxDefence()){
			System.out.printf("Defence cannot be increased over " + gameVariables.getMaxDefence());
			player.defence /= defenceBoost;
			return;
		}
		System.out.printf("Defence increased by %.2f\n",(player.defence - originalDef));
	}

	public static void addStealth(Player player){
		double stealthBoost = (Math.random()*0.5) + 1;
		double originalStealth = player.stealth;
		player.stealth *= stealthBoost;
		if(player.stealth > gameVariables.getMaxStealth()){
			System.out.println("Stealth cannot be increased over " + gameVariables.getMaxStealth());
			player.stealth /= stealthBoost;
			return;
		}
		System.out.printf("Stealth increased by %.2f\n",(player.stealth - originalStealth));
	}
	
	public static void displayCharacter(Player player){
		System.out.println("\nCharacter Page______");
		System.out.printf("Player Role:: %s\n", player.role);
		System.out.printf("Health:: %.2f\n", player.health);
		System.out.printf("Mana:: %.2f\n", player.mana);
		System.out.printf("Damage Phys:: %.2f\n", player.physicalDamage);
		System.out.printf("Damage Mag:: %.2f\n", player.magicDamage);
		System.out.printf("Defence:: %.2f\n", player.defence);
		System.out.printf("Stealth:: %.2f\n", player.stealth);
	}
}

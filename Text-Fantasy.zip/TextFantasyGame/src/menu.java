import java.util.ArrayList;
import java.util.Scanner;

public class menu {
	static Player player = Player.initialisePlayer();
	static Enemy enemy = Enemy.inistialiseEnemy();
	static ArrayList<Enemy> enemyList = Enemy.initialiseEnemyList();
	private static Scanner menuInput = new Scanner(System.in);
	public static void startMenu(){
		System.out.println("Welcome to the fantasy game, Euthanasia");
		System.out.println("Make your choice__\n" 
				+ "1>Start Game\n"
				+ "2>Quit Game");
		System.out.print("Here  :");
		int input = menuInput.nextInt();
		menuInput.nextLine();
		
		switch(input){
		case 1:
			characterSelect();
			break;
		case 2:
			System.out.println("Thank You for playing, can't wait for you to come back.");
			System.exit(0);	
		default:
			System.out.println("Invalid Selection");
			break;
		}	
	}
	
	public static void characterSelect(){
		System.out.println("\nSelect Character Type");
		System.out.println("Make your choice__\n" 
				+ "1>Warrior\n"
				+ "2>Mage\n"
				+ "3>Assasin");
		System.out.print("Here  :");
		int input = menuInput.nextInt();
		menuInput.nextLine();
		
		switch(input){
		case 1:
			Player.createWarrior(player);
			break;
		case 2:
			Player.createMage(player);
			break;
		case 3:
			Player.createAssasin(player);
			break;
		default:
			System.out.println("Invalid Selection");
			break;
		}	
	}
	
	public static void turnMenu(int count){
		System.out.printf("\nSelect Turn %d Action:\n", count);
		System.out.println("Make your choice__\n" 
				+ "1>View Stats\n"
				+ "2>Start Round\n"
				+ "3>Quit");
		System.out.print("Here  :");
		int input = menuInput.nextInt();
		menuInput.nextLine();
		
		switch(input){
		case 1:
			Player.displayCharacter(player);
			turnMenu(count);
			break;
		case 2:
			enemy = Enemy.getFirstStageEnemies(count);
			battleMode(player, enemy);
			if(player.dead == true){
				System.out.println("You have been killed");
				System.out.println("Restart Application to try again.");
				System.exit(0);
			}
			break;
		case 3:
			System.out.println("Thank You for playing, can't wait for you to come back.");
			System.exit(0);	
		default:
			System.out.println("Invalid Selection");
			turnMenu(count);
			break;
		}	
	}
	
	public static void battleMode(Player player, Enemy enemy){
		double enemyOrigHealth = enemy.health;
		while(enemy.killed != true && player.dead != true){
			System.out.println("\nEnemy Data");
			System.out.printf("Name : %s\nHealth : %.2f\nDamage : %.2f\n", enemy.name, enemy.health, enemy.damage);
			System.out.println("\nCharacter Information");
			Player.displayCharacter(player);
			turnResources.playerAttack(player, enemy);
			turnResources.enemyAttack(player, enemy);
		}
		if(player.dead != true){
			turnResources.enemyKillBonus(player);
		}
		Player.displayCharacter(player);
		enemy.health = enemyOrigHealth;
	}
}

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;

public class Enemy {
	String name;
	double health;
	double damage;
	boolean killed;
	static ArrayList<Enemy> enemyList = new ArrayList<Enemy>();
	public Enemy(String name, double health, double damage, boolean killed){
		 this.name = name;
		 this.health = health;
		 this.damage = damage;
		 this.killed = killed;
	}
	
	public static ArrayList<Enemy> initialiseEnemyList(){
		Scanner enemyFile = null;
		try {
			enemyFile = new Scanner(new File("enemyList"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		while(enemyFile.hasNextLine()){
			String listEnemy = enemyFile.nextLine();
			String[] curEnemy = listEnemy.split("//");
			double health = Double.parseDouble(curEnemy[1]);
			double damage = Double.parseDouble(curEnemy[2]);
			Enemy enemy = new Enemy(curEnemy[0], health, damage, false);
			enemyList.add(enemy);
		};
		return enemyList;
	}
	
	public static Enemy inistialiseEnemy(){
		Enemy enemy = new Enemy("n/a",0,0, false);
		return enemy;
	}
	//This function is for getting enemies for the first 10 turns*, as well as finally the first boss.
	//*might change the amount once i have got a runnable game to test.
	public static Enemy getFirstStageEnemies(int count){
		if(count < 10){	
			Random rand = new Random();
			int numberEnemy = rand.nextInt(5);
			return enemyList.get(numberEnemy);	
		}else{
			//this is the index value of the first boss so once the turns are up it will only spawn this
			return enemyList.get(5);
		}

	}
}
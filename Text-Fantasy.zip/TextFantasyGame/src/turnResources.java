import java.util.Random;
import java.util.Scanner;

public class turnResources {
	
	private static Scanner input = new Scanner(System.in);
	public static void playerAttack(Player player,Enemy enemy){
		System.out.println("\nSelect form of Attack");
		System.out.println("1>Physical\n" + "2>Magic\n");
		System.out.print("Here  :");
		int inputAttack = input.nextInt();
		input.nextLine();
		
		switch(inputAttack){
		case 1:
			System.out.printf("You Physically attack the enemy for %.2f\n", player.physicalDamage);
			enemy.health -= player.physicalDamage;
			break;
		case 2:
			System.out.printf("You Magically attack the enemy for %.2f\n", player.magicDamage);
			enemy.health -= player.magicDamage;
			break;
		default:
			System.out.println("You confuse yourself and do nothing.");
			break;
		}
		if(enemy.health <= 0){
			System.out.println("You Killed the monster");
			enemy.killed = true;
		}
	}
	
	public static void enemyAttack(Player player,Enemy enemy){
		if(enemy.killed != true){
			player.health -= enemy.damage;
		}
		if(player.health <= 0){
			System.out.println("You Have Died");
			player.dead = true;
		}
	}
	
	public static void enemyKillBonus(Player player){
		Random rand = new Random();
		int statToIncrease = rand.nextInt(6);
		
		switch(statToIncrease){
		case 1:
			Player.addHealth(player);
			break;
		case 2:
			Player.addMana(player);
			break;
		case 3:
			Player.addPhysicalDamage(player);
			break;
		case 4:
			Player.addMagicDamage(player);
			break;
		case 5:
			Player.addDefence(player);
			break;
		case 6:
			Player.addStealth(player);
			break;
		}
	}
}

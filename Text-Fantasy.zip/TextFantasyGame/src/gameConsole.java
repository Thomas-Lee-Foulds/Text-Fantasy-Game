
public class gameConsole {
	public static void main(String[] args) {
		
		menu.startMenu();
		int count =1;
		while(count<10){
			menu.turnMenu(count);
			count++;
		}
	}

}
